/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package imgcacheparser;

import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.math.BigInteger;
import java.nio.channels.FileChannel;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.bind.DatatypeConverter;
import sun.misc.IOUtils;
import static sun.security.krb5.Confounder.bytes;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/**
 *
 * @author Air
 */
public class ImageRecovery {
//    final private static String subString = "\\x2F\\x00\\x6C\\x00\\x6F\\x00\\x63\\x00\\x61\\x00\\x6C\\x00\\x2F\\x00\\x69\\x00\\x6D\\x00\\x61\\x00\\x67\\x00\\x65\\x00\\x2F\\x00\\x69\\x00\\x74\\x00\\x65\\x00\\x6D\\x00\\x2F\\x00";

//    final private static String subString = "/ l o c a l / i m a g e / i t e m /";
    final private static String subString = "47 0 108 0 111 0 99 0 97 0 108 0 47 0 105 0 109 0 97 0 103 0 101 0 47 0 105 0 116 0 101 0 109 0 47 0";
    final private static int MAXPATH = 200; //100 x UTF16 chars = max path size
    private String inputFile = "C:\\Users\\Air\\Desktop\\imgcache[1].0";
    private int fileSize;

    public ImageRecovery() {
    }

//    Find all indices of a substring in a given string
    private List<Integer> allIndices(String bigString, String subString) {
        List<Integer> listIndex = new ArrayList<>();
        int i = bigString.indexOf(subString, 0);
        while (i >= 0) {
            listIndex.add(i);
            i = bigString.indexOf(subString, i + 1);
        }
        return listIndex;
    }

    public void recoverImages() {

        FileInputStream fileInputStream = null;
//        String hexVal = toHex(subString);
//        System.out.println(hexVal);
        try {
            fileInputStream = new FileInputStream(new File(inputFile));

            fileSize = (int) new File(inputFile).length(); // byte count of the file-content

            byte[] filecontent = new byte[(int) fileSize];
            String fileString = "";

            fileInputStream.read(filecontent, 0, (int) fileSize);
            String str;
           
            str = new String(filecontent, StandardCharsets.UTF_8);
            String fileStr = Arrays.toString(filecontent).replace(",", "");
//            System.out.println(fileStr);

            List<Integer> picHits = allIndices(fileStr, subString);

            System.out.println("Paths found: " + picHits.size());

            for (Integer hit : picHits) {
                boolean jpgfound = false;
                int charcount = 0;
                int jpgstart = 0;
                String pathname = "";

                fileInputStream.getChannel().position(hit);
                fileInputStream.getChannel().position(hit - 0x4);
                
                byte[]picSize = new byte[4];
                fileInputStream.read(picSize,0,4);
              
                System.out.println(ByteBuffer.wrap(picSize).getShort());

            }

        } catch (FileNotFoundException e) {
            System.out.println(e);
        } catch (IOException e) {
            System.out.println(e);
        }
    }

    public String toHex(String arg) {
        return String.format("%040x", new BigInteger(1, arg.getBytes(StandardCharsets.US_ASCII)));
    }

}
